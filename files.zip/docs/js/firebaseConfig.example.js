// Copy this file to docs/js/firebaseConfig.js and replace the placeholders with your Firebase project's config.
// Steps are in README.md.
// IMPORTANT: This file is kept client-side for the demo. Do NOT store sensitive secrets here in production.

export const FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "SENDER_ID",
  appId: "APP_ID"
};

// Demo initial setup: a short code to allow creating the first admin from the UI.
// Set to null or '' to disable the initial setup flow.
export const DEMO_SETUP = {
  enabled: true,
  setupCode: "superprocure-demo-setup-2025"
};