// Main SPA logic (module)
import { FIREBASE_CONFIG, DEMO_SETUP } from './firebaseConfig.js';

// Firebase v9 modular imports from CDN
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import {
  getAuth,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import {
  getFirestore,
  collection,
  addDoc,
  doc,
  setDoc,
  updateDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

const app = initializeApp(FIREBASE_CONFIG);
const auth = getAuth(app);
const db = getFirestore(app);

/* ---------- Helpers ---------- */
const $ = id => document.getElementById(id);
const hide = el => el.classList.add('hidden');
const show = el => el.classList.remove('hidden');

const navRight = $('nav-right') || document.getElementById('nav-right');

/* ---------- UI Elements ---------- */
const authSection = $('auth');
const loginForm = $('login-form');
const registerForm = $('register-form');
const showRegisterBtn = $('show-register');
const showLoginBtn = $('show-login');

const initialSetup = $('initial-setup');
const createAdminBtn = $('create-admin');
const setupCodeInput = $('setup-code');
const adminNameInput = $('admin-name');
const adminEmailInput = $('admin-email');
const adminPasswordInput = $('admin-password');

const adminDashboard = $('admin-dashboard');
const vendorDashboard = $('vendor-dashboard');

const btnCreateIndent = $('btn-create-indent');
const createIndentForm = $('create-indent-form');
const saveIndentBtn = $('save-indent');
const cancelIndentBtn = $('cancel-indent');
const indentsContainer = $('indents-container');

const publishedContainer = $('published-container');
const myBidsContainer = $('my-bids-container');

const bidsForIndent = $('bids-for-indent');
const bidsContainer = $('bids-container');
const bidsIndentTitle = $('bids-indent-title');
const closeBidsBtn = $('close-bids');

let currentEditIndentId = null;
let currentUser = null;

/* ---------- Auth UI handlers ---------- */
showRegisterBtn.addEventListener('click', () => {
  show(registerForm); hide(loginForm);
});
showLoginBtn.addEventListener('click', () => {
  hide(registerForm); show(loginForm);
});

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = $('login-email').value.trim();
  const password = $('login-password').value;
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    alert('Login failed: ' + err.message);
  }
});

registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = $('reg-name').value.trim();
  const email = $('reg-email').value.trim();
  const password = $('reg-password').value;
  if (!name) return alert('Enter name');
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    // create user profile doc
    await setDoc(doc(db, 'users', cred.user.uid), {
      name,
      email,
      role: 'vendor',
      createdAt: serverTimestamp()
    });
    // auto-signed in by Firebase
  } catch (err) {
    alert('Register failed: ' + err.message);
  }
});

if (DEMO_SETUP && DEMO_SETUP.enabled) {
  show(initialSetup);
}
createAdminBtn.addEventListener('click', async () => {
  const code = setupCodeInput.value.trim();
  if (!DEMO_SETUP || code !== DEMO_SETUP.setupCode) return alert('Invalid setup code');
  const name = adminNameInput.value.trim();
  const email = adminEmailInput.value.trim();
  const password = adminPasswordInput.value;
  if (!name || !email || !password) return alert('All fields required');
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await setDoc(doc(db, 'users', cred.user.uid), {
      name, email, role: 'admin', createdAt: serverTimestamp()
    });
    alert('Admin created. You are signed in.');
  } catch (err) {
    alert('Admin creation failed: ' + err.message);
  }
});

/* ---------- Sign out ---------- */
$('btn-signout')?.addEventListener('click', () => signOut(auth));
$('btn-signout-2')?.addEventListener('click', () => signOut(auth));

/* ---------- Admin: create/edit indent ---------- */
btnCreateIndent.addEventListener('click', () => {
  currentEditIndentId = null;
  $('indent-title').value = '';
  $('indent-items').value = '';
  $('indent-required-date').value = '';
  $('indent-published').checked = false;
  show(createIndentForm);
});

cancelIndentBtn.addEventListener('click', () => hide(createIndentForm));

saveIndentBtn.addEventListener('click', async () => {
  const title = $('indent-title').value.trim();
  const items = $('indent-items').value.trim();
  const requiredDate = $('indent-required-date').value || null;
  const published = $('indent-published').checked;

  if (!title || !items) return alert('Title and items required');

  try {
    if (currentEditIndentId) {
      await updateDoc(doc(db, 'indents', currentEditIndentId), {
        title, items, requiredDate, published, updatedAt: serverTimestamp()
      });
    } else {
      await addDoc(collection(db, 'indents'), {
        title, items, requiredDate, published,
        createdBy: currentUser.uid,
        createdAt: serverTimestamp()
      });
    }
    hide(createIndentForm);
  } catch (err) {
    alert('Save failed: ' + err.message);
  }
});

/* ---------- Utility renderers ---------- */
function renderIndents(list, container, isAdmin=false) {
  container.innerHTML = '';
  if (list.length === 0) {
    container.innerHTML = '<div class="small muted">No indents found.</div>';
    return;
  }
  list.forEach(docSnap => {
    const id = docSnap.id;
    const d = docSnap.data();
    const el = document.createElement('div');
    el.className = 'indent';
    el.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <strong>${escapeHtml(d.title || '')}</strong>
          <div class="small">${escapeHtml(d.items || '')}</div>
          <div class="small muted">Required: ${d.requiredDate || '—'}</div>
        </div>
        <div style="text-align:right">
          <div class="small muted">Published: ${d.published ? 'Yes' : 'No'}</div>
          <div style="margin-top:0.5rem"></div>
        </div>
      </div>
    `;
    if (isAdmin) {
      const btnRow = document.createElement('div');
      btnRow.className = 'row';
      const edit = document.createElement('button');
      edit.className = 'btn secondary';
      edit.textContent = 'Edit';
      edit.onclick = () => {
        currentEditIndentId = id;
        $('indent-title').value = d.title || '';
        $('indent-items').value = d.items || '';
        $('indent-required-date').value = d.requiredDate || '';
        $('indent-published').checked = !!d.published;
        show(createIndentForm);
      };
      const togglePub = document.createElement('button');
      togglePub.className = 'btn';
      togglePub.textContent = d.published ? 'Unpublish' : 'Publish';
      togglePub.onclick = async () => {
        await updateDoc(doc(db, 'indents', id), { published: !d.published });
      };
      const viewBids = document.createElement('button');
      viewBids.className = 'btn outline';
      viewBids.textContent = 'View bids';
      viewBids.onclick = () => openBidsForIndent(id, d.title);
      btnRow.append(edit, togglePub, viewBids);
      el.appendChild(btnRow);
    } else {
      const bidBtn = document.createElement('button');
      bidBtn.className = 'btn';
      bidBtn.textContent = 'Submit bid';
      bidBtn.onclick = () => openSubmitBidDialog(id, d.title, d.items);
      el.appendChild(bidBtn);
    }
    container.appendChild(el);
  });
}

function renderPublished(list) {
  publishedContainer.innerHTML = '';
  if (list.length === 0) {
    publishedContainer.innerHTML = '<div class="small muted">No published indents.</div>';
    return;
  }
  list.forEach(docSnap => {
    const id = docSnap.id;
    const d = docSnap.data();
    const el = document.createElement('div');
    el.className = 'published-item';
    el.innerHTML = `<strong>${escapeHtml(d.title)}</strong>
      <div class="small">${escapeHtml(d.items)}</div>
      <div class="small muted">Required: ${d.requiredDate || '—'}</div>`;
    const bidBtn = document.createElement('button');
    bidBtn.className = 'btn';
    bidBtn.textContent = 'Submit bid';
    bidBtn.onclick = () => openSubmitBidDialog(id, d.title, d.items);
    el.appendChild(bidBtn);
    publishedContainer.appendChild(el);
  });
}

function renderMyBids(list) {
  myBidsContainer.innerHTML = '';
  if (list.length === 0) {
    myBidsContainer.innerHTML = '<div class="small muted">No bids submitted yet.</div>';
    return;
  }
  list.forEach(d => {
    const el = document.createElement('div');
    el.className = 'my-bid';
    el.innerHTML = `<strong>${escapeHtml(d.indentTitle)}</strong>
      <div class="small">Price: ${escapeHtml(String(d.price))}</div>
      <div class="small">Delivery (days): ${escapeHtml(String(d.deliveryDays || '—'))}</div>
      <div class="small muted">Status: ${escapeHtml(d.status || 'submitted')}</div>`;
    myBidsContainer.appendChild(el);
  });
}

/* ---------- Submit bid dialog (simple prompt-based for demo) ---------- */
async function openSubmitBidDialog(indentId, title, items) {
  const price = prompt(`Submit bid for "${title}"\n\nItems:\n${items}\n\nEnter price (numeric):`);
  if (price === null) return;
  const delivery = prompt('Enter delivery timeline (days)');
  const docs = prompt('Optional docs link (URL)', '');
  try {
    await addDoc(collection(db, 'bids'), {
      indentId,
      indentTitle: title,
      vendorId: currentUser.uid,
      vendorName: currentUser.displayName || currentUser.email,
      price: Number(price) || price,
      deliveryDays: delivery || null,
      docsLink: docs || null,
      status: 'submitted',
      createdAt: serverTimestamp()
    });
    alert('Bid submitted');
  } catch (err) {
    alert('Failed to submit bid: ' + err.message);
  }
}

/* ---------- Admin: open bids for indent ---------- */
let unsubscribeBidsListener = null;
async function openBidsForIndent(indentId, indentTitle) {
  bidsForIndent.classList.remove('hidden');
  bidsIndentTitle.textContent = indentTitle;
  bidsContainer.innerHTML = 'Loading...';
  if (unsubscribeBidsListener) unsubscribeBidsListener();

  const q = query(collection(db, 'bids'), where('indentId', '==', indentId), orderBy('createdAt', 'asc'));
  unsubscribeBidsListener = onSnapshot(q, snapshot => {
    bidsContainer.innerHTML = '';
    if (snapshot.empty) {
      bidsContainer.innerHTML = '<div class="small muted">No bids yet.</div>';
      return;
    }
    snapshot.forEach(docSnap => {
      const bid = docSnap.data();
      const id = docSnap.id;
      const el = document.createElement('div');
      el.className = 'bid';
      el.innerHTML = `<strong>${escapeHtml(bid.vendorName || bid.vendorId)}</strong>
        <div class="small">Price: ${escapeHtml(String(bid.price))}</div>
        <div class="small">Delivery: ${escapeHtml(String(bid.deliveryDays || '—'))}</div>
        <div class="small muted">Status: ${escapeHtml(bid.status || '')}</div>
        <div class="small">${bid.docsLink ? `<a target="_blank" href="${escapeAttr(bid.docsLink)}">Attachment</a>` : ''}</div>`;
      const approve = document.createElement('button');
      approve.className = 'btn';
      approve.textContent = 'Approve';
      approve.onclick = async () => {
        await updateDoc(doc(db, 'bids', id), { status: 'approved', decisionAt: serverTimestamp() });
        // optional: mark indent winner
        await updateDoc(doc(db, 'indents', indentId), { winnerBidId: id });
      };
      const reject = document.createElement('button');
      reject.className = 'btn secondary';
      reject.textContent = 'Reject';
      reject.onclick = async () => {
        await updateDoc(doc(db, 'bids', id), { status: 'rejected', decisionAt: serverTimestamp() });
      };
      el.appendChild(approve);
      el.appendChild(reject);
      bidsContainer.appendChild(el);
    });
  }, err => {
    bidsContainer.innerHTML = 'Listener error: ' + err.message;
  });
}

closeBidsBtn.addEventListener('click', () => {
  bidsForIndent.classList.add('hidden');
  if (unsubscribeBidsListener) { unsubscribeBidsListener(); unsubscribeBidsListener = null; }
});

/* ---------- Firestore listeners for indents and published items ---------- */
let unsubscribeIndents = null;
let unsubscribePublished = null;
let unsubscribeMyBids = null;

function attachAdminIndentsListener() {
  if (unsubscribeIndents) unsubscribeIndents();
  const q = query(collection(db, 'indents'), orderBy('createdAt', 'desc'));
  unsubscribeIndents = onSnapshot(q, snapshot => {
    renderIndents(snapshot.docs, indentsContainer, true);
  });
}
function attachPublishedListener() {
  if (unsubscribePublished) unsubscribePublished();
  const q = query(collection(db, 'indents'), where('published', '==', true), orderBy('createdAt', 'desc'));
  unsubscribePublished = onSnapshot(q, snapshot => {
    renderPublished(snapshot.docs);
  });
}
function attachMyBidsListener(uid) {
  if (unsubscribeMyBids) unsubscribeMyBids();
  const q = query(collection(db, 'bids'), where('vendorId', '==', uid), orderBy('createdAt', 'desc'));
  unsubscribeMyBids = onSnapshot(q, snapshot => {
    const arr = [];
    snapshot.forEach(s => arr.push(s.data()));
    renderMyBids(arr);
  });
}

/* ---------- Auth state & role routing ---------- */
onAuthStateChanged(auth, async user => {
  currentUser = user;
  if (!user) {
    // show auth
    show(authSection); hide(adminDashboard); hide(vendorDashboard);
    hide(createIndentForm); hide(bidsForIndent);
    // stop listeners
    unsubscribeIndents?.();
    unsubscribePublished?.();
    unsubscribeMyBids?.();
    return;
  }
  // get user profile
  const userDoc = await getDocs(query(collection(db, 'users'), where('__name__', '==', user.uid)));
  // simplified: try to read users/{uid}
  const uRef = doc(db, 'users', user.uid);
  try {
    // read doc
    const res = await getDocs(query(collection(db, 'users'), where('__name__', '==', user.uid)));
  } catch(e) {
    // ignore
  }
  // get role by reading document
  let role = null;
  // attempt to get doc directly
  try {
    const snap = await getDocs(collection(db, 'users')); // cheap fallback; we'll try direct get below
  } catch(e) { /* ignore */ }
  // direct get:
  try {
    const { default: fetchDoc } = await import('https://cdn.jsdelivr.net/gh/lukasoppermann/fetcher@1.0.0/unused.js').catch(()=>({default:null}));
  } catch(e){}
  // Instead of remote import, do simple get from Firestore using getDocs on the doc path:
  try {
    const docRef = doc(db, 'users', user.uid);
    const docSnap = await (await import("https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js")).getDoc?.(docRef);
    // NOTE: some browsers may not support calling getDoc through dynamic import. If that fails, fallback:
    let userDocSnap = null;
    if (docSnap && docSnap.exists && docSnap.exists()) userDocSnap = docSnap;
    if (!userDocSnap) {
      // fallback: query users where email == user.email
      const q = query(collection(db, 'users'), where('email', '==', user.email));
      const qr = await getDocs(q);
      if (!qr.empty) {
        const first = qr.docs[0];
        role = first.data().role;
        user.displayName = first.data().name || user.displayName;
      }
    } else {
      role = userDocSnap.data().role;
      user.displayName = userDocSnap.data().name || user.displayName;
    }
  } catch (err) {
    // final fallback: assume vendor
    role = 'vendor';
  }

  // Simple robust approach: try to read users/{uid} using getDocs on collection + where __name__ equals uid
  try {
    const q = query(collection(db, 'users'), where('__name__', '==', user.uid));
    const snap = await getDocs(q);
    if (!snap.empty) {
      role = snap.docs[0].data().role;
      user.displayName = snap.docs[0].data().name || user.displayName;
    } else {
      // fallback: try email match
      const q2 = query(collection(db, 'users'), where('email', '==', user.email));
      const snap2 = await getDocs(q2);
      if (!snap2.empty) {
        role = snap2.docs[0].data().role;
        user.displayName = snap2.docs[0].data().name || user.displayName;
      }
    }
  } catch (err) { role = role || 'vendor' }

  // Update nav
  navRight.innerHTML = `<span class="small muted">Hi ${escapeHtml(user.displayName || user.email)}</span>`;

  hide(authSection);
  if (role === 'admin') {
    show(adminDashboard); hide(vendorDashboard);
    attachAdminIndentsListener();
    attachPublishedListener(); // admin may still want to see published list
  } else {
    show(vendorDashboard); hide(adminDashboard);
    attachPublishedListener();
    attachMyBidsListener(user.uid);
  }
});

/* ---------- Simple escaping helpers ---------- */
function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/[&<>"']/g, s => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[s]));
}
function escapeAttr(s) {
  if (!s) return '';
  return String(s).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* ---------- Small notifications for dev ---------- */
console.info('SuperProcure demo loaded. Make sure docs/js/firebaseConfig.js exists and is configured (see README).');