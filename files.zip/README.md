```markdown
# SuperProcure — Procurement demo (GitHub Pages + Firebase)

This repository contains a small working procurement application (demo) that runs as a static site on GitHub Pages and uses Firebase (Authentication + Firestore) as a backend. It demonstrates an Admin who can create day-wise purchase indents and Vendors who can register and submit bids.

IMPORTANT: This project is a demo to show workflows. Do NOT use it in production without proper security rules, server-side controls, and secrets management.

---

Contents
- docs/index.html — Single page app (SPA)
- docs/css/style.css — Simple styles
- docs/js/firebaseConfig.example.js — Example config; copy to firebaseConfig.js
- docs/js/app.js — Main application logic (modular ES module; uses Firebase v9 via CDN)
- .nojekyll
- .github/workflows/deploy.yml — optional deploy to gh-pages

Quick start (create a working demo)

1) Create a GitHub repository and push these files (place contents under repository root).
   - The site is ready to serve using the `/docs` folder on GitHub Pages.

2) Create a Firebase Project
   - Go to https://console.firebase.google.com/
   - Create a new project (or use an existing one).
   - In Build → Authentication → Sign-in method enable "Email/Password".
   - In Build → Firestore Database create a Firestore database in production or test mode (for demo you can use test mode).
   - (Optional) Add security rules later. For demo, test mode is easiest.

3) Configure the app
   - In Firebase Console → Project settings → General → your apps → Add web app.
   - Copy the firebaseConfig snippet (apiKey, authDomain, projectId, etc).
   - In the repo, go to `docs/js/` and copy `firebaseConfig.example.js` to `firebaseConfig.js`, then replace placeholders with your project's config.
   - Keep `DEMO_SETUP.setupCode` — you'll need the value to create the first admin via the UI.

4) Create the first Admin (initial setup)
   - Open the site (locally or on GitHub Pages) and use the "Initial Admin Setup" panel.
   - Enter the setup code from firebaseConfig.js, admin name/email/password — this will create an admin account and a `users/{uid}` document with role `admin`.
   - Alternatively you can create a user via Firebase Console and manually add the corresponding doc in Firestore collection `users` with field `role: "admin"`.

5) Vendor registration
   - Vendors can register themselves via the Register form. That creates an Auth user and a Firestore users document with role `vendor`.

6) Using the application
   - Admin:
     - Create indents (title, items/specs, required date). Can publish/unpublish.
     - Click "View bids" for an indent to see vendor submissions and Approve/Reject.
   - Vendor:
     - View published indents and submit bids (simple prompt based input).
     - View their bid status in "My Bids".

7) Deploy to GitHub Pages
   - In GitHub repository → Settings → Pages
     - Source: Branch `main` (or `master`) and folder `/docs`
   - Or enable the included GitHub Actions workflow to publish `docs/` to `gh-pages`.

Notes, limitations and security
- This is a client-only demo. Any "admin creation" or "setup code" in the client is insecure for production and only intended to make a runnable demo for evaluation.
- You must add proper Firestore rules before using this with real data.
- For email notifications, file uploads, or sensitive business logic consider server-side Cloud Functions.
- Price comparisons and complex bidding flows can be added as features; this demo shows a minimal workable flow.

Want me to:
- Add proper Firestore rules example for admin/vendor roles?
- Add email notifications using EmailJS or Firebase Cloud Functions?
- Improve UI and add CSV export / reports?
- Add a GitHub Action to automatically deploy on push?
Respond with what you'd like next and I will update the repo files.
```